package com.apps.canvasdemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.PathShape;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class CustomView extends View {
    Paint redPaint = new Paint();
    Paint bluePaint = new Paint();
    Paint greenPaint = new Paint();
    Bitmap tile;

    private void init() {
        redPaint.setColor(Color.GREEN);
        bluePaint.setColor(Color.RED);

    }
    public CustomView(Context context) {
        super(context);
        init();
    }

    public CustomView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public void setBitmap(Bitmap tileImage){
        tile=tileImage;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Path p=new Path();
//        p.moveTo(0,0);
        p.moveTo(getWidth(),0);
        p.lineTo(getWidth()-getHeight(),getHeight());
        p.lineTo(getHeight(),getHeight());
        p.lineTo(0,0);
        p.close();

//        Path animPath = new Path();
//        animPath.moveTo(100, 100);
//        animPath.lineTo(200, 100);
//        animPath.lineTo(300, 50);
//        animPath.lineTo(400, 150);
//        animPath.lineTo(100, 300);
//        animPath.lineTo(600, 300);
//        animPath.lineTo(100, 100);
//        animPath.close();
//
//
//        redPaint.setStrokeWidth(10.0f);

        if(tile!=null) {
            Shader shader = new BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
            redPaint.setShader(shader);
            redPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));

//            canvas.drawBitmap(tile,0,0,redPaint);
        }
        canvas.drawPath(p,redPaint);
//        canvas.drawPath(animPath,bluePaint);


    }

}
