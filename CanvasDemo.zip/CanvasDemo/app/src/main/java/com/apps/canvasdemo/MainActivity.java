package com.apps.canvasdemo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    CustomView cvTop, cvBottom;
    CustomViewVerticle cvLeft, cvRight;
    ImageView topBorder, leftBorder;
    RelativeLayout captureImage, captureImageVerticle;
    int ver_height, frameWidth, hori_width;
    Bitmap horiZontalFrameBmp, verticalFrameBmp;

    List<String> frameList;
    int i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frameList=new ArrayList<>();
      /*  frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1432.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1280.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1281.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1282.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1283.jpg");*/
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1139.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1139.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1139.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1139.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1139.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1139.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1139.jpg");
       /* frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1284.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1285.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1286.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1432.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1287.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1288.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1289.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1264.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1265.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1267.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1268.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1269.jpg");*/

        /*frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1479.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1480.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1432.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1481.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1482.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1483.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1484.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1485.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1486.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1487.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1488.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1489.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1464.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1465.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1467.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1468.jpg");
        frameList.add("https://www.frameshop.com.au/images/frame_images/large/top_frame_1469.jpg");*/

        topBorder = findViewById(R.id.topBorder);
        leftBorder = findViewById(R.id.leftBorder);

        cvTop = findViewById(R.id.cvTop);
        cvBottom = findViewById(R.id.cvBottom);
        captureImage = findViewById(R.id.captureImage);

        captureImage.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                hori_width = captureImage.getWidth();
                frameWidth = captureImage.getHeight();
                Log.e("widthFramee",+hori_width+ "  heightFramee  : "+frameWidth );

            }
        });


        cvLeft = findViewById(R.id.cvLeft);
        cvRight = findViewById(R.id.cvRight);
        captureImageVerticle = findViewById(R.id.captureImageVerticle);
        captureImageVerticle.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {

                ver_height=captureImageVerticle.getHeight();
                frameWidth=captureImageVerticle.getWidth();

            }
        });


        final Handler h=new Handler();
        Runnable r=new Runnable() {
            @Override
            public void run() {
                h.postDelayed(this,5000);
                i++;
                LoadFrames(frameList.get(i%frameList.size()));
            }
        };

        h.post(r);


    }

    public void LoadFrames(String url){
        Glide.with(this).asBitmap().load(url).diskCacheStrategy(DiskCacheStrategy.NONE).listener(new RequestListener<Bitmap>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Bitmap> target, boolean isFirstResource) {
                return false;
            }

            @Override
            public boolean onResourceReady(final Bitmap resource, Object model, Target<Bitmap> target, DataSource dataSource, boolean isFirstResource) {

                Log.e("Glide", "image downloaded");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        Bitmap bOutput;

                        float degrees = -90; //rotation degree
                        Matrix matrix = new Matrix();
                        matrix.setRotate(degrees);
                        bOutput = Bitmap.createBitmap(resource, 0, 0, resource.getWidth(), resource.getHeight(), matrix, true);

                        topBorder.setImageBitmap(resource);
                        leftBorder.setImageBitmap(bOutput);
                        setHoriZontalFrameBmp();
                        setVerticalFrameBmp();
                    }
                });

                return false;
            }
        }).into(0, 50);
    }


    public void setHoriZontalFrameBmp() {
        Bitmap hori = Bitmap.createBitmap(hori_width, frameWidth, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(hori);
        captureImage.draw(c);
        cvTop.setBitmap(hori);
        cvBottom.setBitmap(hori);

    }

    public void setVerticalFrameBmp(){
        Bitmap b = Bitmap.createBitmap(frameWidth, ver_height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        captureImageVerticle.draw(c);
        verticalFrameBmp = b;
        cvLeft.setBitmap(b);
        cvRight.setBitmap(b);
    }
}
