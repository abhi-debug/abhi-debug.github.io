package com.apps.canvasdemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class CustomViewVerticle extends View {
    Paint redPaint = new Paint();
    Paint bluePaint = new Paint();
    Paint greenPaint = new Paint();
    Bitmap tile;

    private void init() {
        redPaint.setColor(Color.GREEN);
        bluePaint.setColor(Color.RED);

    }
    public CustomViewVerticle(Context context) {
        super(context);
        init();
    }

    public CustomViewVerticle(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomViewVerticle(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public void setBitmap(Bitmap tileImage){
        tile=tileImage;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Path p=new Path();
        p.moveTo(0,0);
        p.moveTo(getWidth(),getWidth());
        p.lineTo(getWidth(),getHeight()-getWidth());
        p.lineTo(0,getHeight());
        p.lineTo(0,0);
        p.close();

        if(tile!=null) {
            Shader shader = new BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
            redPaint.setShader(shader);
            redPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));

        }
        canvas.drawPath(p,redPaint);
//        canvas.drawPath(animPath,bluePaint);


    }

}
